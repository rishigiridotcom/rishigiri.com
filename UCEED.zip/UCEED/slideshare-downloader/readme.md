# Slideshare Downloader

This python script to download slide from Slideshare and converted into pdf automatically.

## How to setup

	git clone https://github.com/yodiaditya/slideshare-downloader.git
    pip install -r requirements.txt

## How to run

    python convertpdf.py


Then it will asked the slideshare url, some example :

http://www.slideshare.net/habibayuba/accounting-principles-and-concepts-41891654