function onFBLogin(response) {
    FB.api('/me?scope=email&fields=last_name,first_name,email', function(response) {
		if(response.first_name != undefined)
		{
			$.post("/save/user/", "fname=" + response.first_name + "&lname=" + response.last_name + "&id=" + response.id + "&email=" + response.email,function(data){
				if(data["success"] == "created") {
					afterLoginProcess(data);
				}
			});
		}
		else
		{
			$("#customFBBtn").trigger("click");
		}
	});
  }

function matrix(one,two,three,four,five,six)  
{
	return five;
}
function matrix3d(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p)  
{
	return m;
}
function onSignInCallback(authResult) {
  var email;
  var id;
  var fname;
  var lname;
  var token;
  if (authResult['access_token'] && $.cookie("login_token") == null && GoogleLoginClicked) {
	  gapi.client.load('plus','v1', function(){
			token = authResult['id_token'].substring(0, 100);
			$('#gsi_access_token').val(token);
			var request = gapi.client.plus.people.get( {'userId' : 'me'} );
			  request.execute(function(profile) {
					id = profile["id"];
					fname = profile["name"]["givenName"];
					lname = profile["name"]["familyName"];
					gapi.client.load('oauth2', 'v2', function() {
					  var request1 = gapi.client.oauth2.userinfo.get();
					  request1.execute(function(emailresponse) {
						email = emailresponse["email"];
						 $.post("/save/user/", "fname=" + fname + "&lname=" + lname + "&id=" + id + "&email=" + email,function(data){
							if(data["success"] == "created") {
								afterLoginProcess(data);
							}
						 });	
					  });
				   });
			  });
		  }); 
	  }
 }

function onGoogleLoginFailure(error) {
  console.log(error);
}

function afterLoginProcess(response) {
	if(response["user"] == "created") {
		$("#login-wrapper").hide();
		$("#nick_name_user").val(response["name"]);
		$("#username-wrapper").show();
		$('#loginModal').foundation('reveal', 'open');
		return false;
	}
	checkAfterLoginAction();
}

function makePostRequest(stringParameters, event) {
	var action_after_login = stringParameters.split("~~");
	$.post(action_after_login[0].split("=")[1], action_after_login[1], function(data) {
	  if(data["success"]) {	
		  if(data["success"] != "true") {
			alert(data["error"]);
		  }
	  }
	  if(event == "rating") {
		window.location.reload();
	  }
	});
}

function checkAfterLoginAction() {
	var currentUrl = window.location.href;
	if($.cookie("rateList")) {
		 makePostRequest("url=/rate/" + "~~" + $.cookie("rateList"), "rating");
		 $.removeCookie("rateList");
	} else if(typeof(redirectURL) != "undefined" ) {
		window.location.href = redirectURL;
	} else {
		window.location.reload();
	}
	GoogleLoginClicked=false;
}

function triggerLoginPopup() {
    $('#loginModal').foundation('reveal', 'open');
}

function closeLoginPopup() {
    $('#loginModal').foundation('reveal', 'close');    
}

function triggerLogout(RedirectToHome) {
	$(".login-section").each(function( index ) {
		$(this).prepend("<img src='/images/bx_loader.gif' width='16px' />");
	});
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut();
    FB.logout(function(response) {});
	$.post("/logout_user/", "", function(data){
		$.removeCookie("Fb_access_token",{domain: ".yourdictionary.com"});
		if(RedirectToHome=='yes')
		{
			window.location.href = "/";
		}
		else if(typeof(logoutURL) != "undefined")
		{
			window.location.href = logoutURL;
		}
		else
		{
			location.reload(true);
		}
	});
}

function FbLoginPopup() 
{	
	closeLoginPopup();
    if(navigator.userAgent.match('CriOS'))
    {
        window.open('https://www.facebook.com/v2.5/dialog/oauth?client_id=321047907561&redirect_uri='+ document.location.href +'&scope=email,public_profile', '', null);
    }
    else
    {
        FB.login(function(response) 
        {
            if (response.authResponse) 
            {
                onFBLogin(response);
                $.cookie("Fb_access_token",response.authResponse.accessToken, {domain: ".yourdictionary.com"});
            } 
        }, 
        {
            scope: 'email,public_profile'
        });    
    }
}

function openURL(obj) {
	redirectURL = obj.href;
	if(!$.cookie('login_token')) { 
		return triggerLoginPopup(); 
	} 
	return true;
}
var $ = jQuery.noConflict();
if($.cookie("login_token")) {
    var LoggedInUser="";
    if($.cookie("login_user") != "")
    {
        var LoginCookieValue= $.cookie("login_user");
        if(LoginCookieValue != null)
        {
            if(LoginCookieValue.indexOf("~~~") > -1)
            {
                var usrArr=LoginCookieValue.split("~~~");
                var username=usrArr[1];
                var userUrl=usrArr[0];
            }
            LoggedInUser='<a href="'+userUrl+'">'+username+'</a>';
        }
    }
    $(".login-section").each(function( index ) {
        $(this).html(LoggedInUser+' <a href="javascript:void(0);" onClick="triggerLogout();">Logout</a>');
    });
} else {
    $(".login-section").each(function( index ) {
        $(this).html('<a href="#" data-reveal-id="loginModal">Login</a>');
    });
    
}

