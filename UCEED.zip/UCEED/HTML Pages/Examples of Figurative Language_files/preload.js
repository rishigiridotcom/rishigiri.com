function write(str)
{
   document.write(str);
}

function getQuerystring(key, default_)
{
  if (default_==null) default_=""; 
  key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
  var qs = regex.exec(window.location.href);
  if(qs == null)
    return default_;
  else
    return qs[1];
}

function querystring(key) {
   var re=new RegExp('(?:\\?|&)'+key+'=(.*?)(?=&|$)','gi');
   var r=[], m;
   while ((m=re.exec(document.location.search)) != null) r.push(m[1]);
   return r;
}

function setCookie(c_name,value,exdays)
{
    var exdate=new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
    document.cookie=c_name + "=" + c_value + "; path=/;domain=yourdictionary.com";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

function make_blank_about1()
{
    if(document.getElementById("search1"))
    {
        document.getElementById("search1").style.background = 'none';
    }
}

function PlayPron()
{
   swfobject.embedSWF('/includes/audio.swf', 'sound', "1", "1", "8.0.0", '/includes/expressinstall.swf', {audioPath: "/audio/" + pron_path});
} 

function writeLegal(dictionary_slug)
{
    document.write('<small class="ftr-inline">');
    switch (dictionary_slug) 
    {
        case '': 
            document.write('<a href="http://www.yourdictionary.com/dictionary-definitions/">Webster\'s New World College Dictionary</a> Copyright © 2010 by Wiley Publishing, Inc., Cleveland, Ohio. <br />Used by arrangement with John Wiley & Sons, Inc.');
            break;
        case 'law': 
            document.write('<a href="http://law.yourdictionary.com/">Webster\'s New World Law Dictionary</a> Copyright © 2010 by Wiley Publishing, Inc., Hoboken, New Jersey. <br />Used by arrangement with John Wiley & Sons, Inc.');
            break;            
        case 'finance': 
            document.write('<a href="http://invest.yourdictionary.com/">Webster\'s New World Finance and Investment Dictionary</a> Copyright &copy; 2010 by Wiley Publishing, Inc., Indianapolis, Indiana. <br />Used by arrangement with John Wiley &amp; Sons, Inc.');
            break;
        case 'telecom': 
            document.write('<a href="http://computer.yourdictionary.com/">Webster\'s New World Telecom Dictionary</a> Copyright &copy; 2010 by Wiley Publishing, Inc., Indianapolis, Indiana. <br />Used by arrangement with John Wiley &amp; Sons, Inc.');
            break;
        case 'hacker': 
            document.write('<a href="http://computer.yourdictionary.com/">Webster\'s New World Hacker Dictionary</a> Copyright &copy; 2010 by Bernadette Schell and Clemens Martin.<br />Published by Wiley Publishing, Inc., Indianapolis, Indiana. <br />Used by arrangement with John Wiley &amp; Sons, Inc.');
            break;
        case 'computer': 
            document.write('<p><a href="http://www.computerlanguage.com/ydict.html" rel="nofollow" target="_blank">Computer Desktop Encyclopedia</a> THIS DEFINITION IS FOR PERSONAL USE ONLY All other reproduction is strictly prohibited without permission from the publisher. © 1981-2016 The Computer Language Company Inc. All rights reserved.</p>');
            break;
        case 'biography': 
            document.write('<a href="http://biography.yourdictionary.com/">Encyclopedia of World Biography</a>. Copyright 2010 The Gale Group, Inc. All rights reserved.');
            break;
        case 'ah_dict': 
            document.write('The American Heritage® Dictionary of the English Language, 5th edition Copyright © 2013 by Houghton Mifflin Harcourt Publishing Company. Published by Houghton Mifflin Harcourt Publishing Company. All rights reserved.');
            break;
        case 'ah_synonym': 
            document.write('<a href="/synonyms/">The American Heritage® Dictionary of the English Language</a>, 4th edition Copyright © 2010 by Houghton Mifflin Harcourt Publishing Company. Published by Houghton Mifflin Harcourt Publishing Company. All rights reserved.');
            break;
        case 'thesaurus': 
            document.write('<a href="http://thesaurus.yourdictionary.com/">Roget\'s II The New Thesaurus</a> Copyright © 2010 by Houghton Mifflin Harcourt Publishing Company. Published by Houghton Mifflin Harcourt Publishing Company. All rights reserved.');
            break;
        case 'yd-biography': 
            document.write('YourDictionary <a href="http://biography.yourdictionary.com/">biography</a>. Copyright © 2013 LoveToKnow Corp. All rights reserved.');
            break;
        case 'ologies': 
            document.write('<a href="http://www.yourdictionary.com/dictionary-definitions/">Ologies & -Isms.</a> Copyright 2010 The Gale Group, Inc. All rights reserved.');
            break;
        case 'wiktionary':
            document.write('English Wiktionary. Available under&nbsp;<a target="_blank" href="http://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>&nbsp;license.');
            break;
        case 'custom':
            document.write('YourDictionary definition and usage example. Copyright © 2016 by LoveToKnow Corp');
            break;
    }
    document.write('</small>');
}

function writefooter(display_year)
{
    write('<footer class="row pagination-centered" role="contentinfo">'+
    '  <div class="twelve large-12 columns">'+
    '    <hr />'+
    '    <ul class="inline-list" role="navigation">'+
    '        <li><a href="http://www.yourdictionary.com/about.html" onClick="ga(\'send\', \'event\', {eventCategory: \'About page from footer\',eventAction: \'Click\'});">About YourDictionary</a></li>'+
    '        <li><a href="http://www.yourdictionary.com/about/adopp.html" onClick="ga(\'send\', \'event\', {eventCategory: \'Advertisers page from footer\',eventAction: \'Click\'});">Advertisers</a></li>'+
    '        <li><a href="http://www.yourdictionary.com/about/contact.html" onClick="ga(\'send\', \'event\', {eventCategory: \'Contact Us page from footer\',eventAction: \'Click\'});">Contact Us</a></li>'+
    '        <li><a href="http://www.yourdictionary.com/about/privacy.html" onClick="ga(\'send\', \'event\', {eventCategory: \'Privacy Policy page from footer\',eventAction: \'Click\'});">Privacy Policy</a></li>'+
    '        <li><a href="http://www.yourdictionary.com/about/terms-of-use.html" onClick="ga(\'send\', \'event\', {eventCategory: \'Terms of Use page from footer\',eventAction: \'Click\'});">Terms of Use</a></li>'+
    '        <li><a href="http://www.yourdictionary.com/dicthelp.html" onClick="ga(\'send\', \'event\', {eventCategory: \'Help page from footer\',eventAction: \'Click\'});">Help</a></li>'+
    '        <li><a href="https://www.surveymonkey.com/s/52K2Z79" target="_blank" onClick="ga(\'send\', \'event\', {eventCategory: \'Suggestion Box page from footer\',eventAction: \'Click\'});">Suggestion Box</a></li>'+
    '        <li><a href="http://www.yourdictionary.com/dictionary_tools.html" onClick="ga(\'send\', \'event\', {eventCategory: \'Tools page from footer\',eventAction: \'Click\'});">Tools</a></li>    '+
    '    </ul>'+
    '<div id="bottom-login" class="right login-section twelve large-12 columns"></div>'+
    '    <p class="text-center footer_content"><small>&copy; 1996-' + display_year + ' LoveToKnow, Corp. All Rights Reserved. Audio pronunciation provided by LoveToKnow, Corp.</small></p>'+
    '  </div>'+
    '</footer>');
}

function pop_info(src, id)
{
   linkClicked=true;
   var link = $(src);
   var pos = link.offset();
   var width = link.width();
   var height = link.height();
   var box = $('#' + id);
   box.css({"left": pos.left + "px", "top": (pos.top + height + 2) + "px"});
   box.mouseleave(function(){box.hide();});
   box.toggle();
   setTimeout(function(){
    linkClicked=false;
   },500)
}

function recalculatePosition()
{
    var link = $('.link-cite');
    var pos = link.offset();
    var width = link.width();
    var height = link.height();
    var box = $('#link-cite-box');
    box.css({"left": pos.left + "px", "top": (pos.top + height + 2) + "px"});
}

function changeSearchWidth()
{
    var diffInPixels = 70;
    var browserWidth = window.innerWidth || document.documentElement.clientWidth;
    if(browserWidth <= 898 )
    {
        diffInPixels = 50;
    }
    else if(browserWidth >= 1050) 
    {
        diffInPixels = 90;
    }
    if(browserWidth >= 750) 
    {
        var widthSearch = $("#ydHeaderContainer").width()-($("#headwordButtons").width()+$("#floater").width()+$("#YdLogoContainer").width()+diffInPixels);
        if (widthSearch < 225)
        {
            $("#floater").css("display","none");
            $("#floater_small_buttons").css("display","block");
            widthSearch = $("#ydHeaderContainer").width()-($("#headwordButtons").width()+$("#floater_small_buttons").width()+$("#YdLogoContainer").width()+diffInPixels);
        }
        else
        {
            $("#floater").css("display","block");
            $("#floater_small_buttons").css("display","none");
        }
        $("#floaterContainer #searchbox").css("width",widthSearch+"px");
        $("#floaterContainer .searchField").css("width",((widthSearch-45)+"px"));
    }
    else
    {
        var widthSearch = $("#ydHeaderContainer").width()-($("#YdLogoContainer").width()+diffInPixels);
        $("#YdSearchContainer #searchbox").css("width",widthSearch+"px");
        $("#YdSearchContainer #yd_search_bar").css("width",((widthSearch-45)+"px"));
    }
    $("#YdSearchContainer").css("width",(($("#ydHeaderContainer").width()-$("#YdLogoContainer").width()))+"px");
}

function setBackgroundPosition() 
{
    if($(".backgroundSection").length > 0) {
        setTimeout(function(){
            $(".backgroundSection").width($(window).width());
            $(".backgroundSection").css("margin-left","-"+$("#breadCrumbAndSocial").offset().left+"px");
            $(".backgroundHeading h1").css("padding-left",$("#breadCrumbAndSocial").offset().left+"px");
            $(".backgroundHeading").css("margin-top",(($(".backgroundSection").height()/2)-($(".backgroundHeading h1").height()/2))+"px");
        },300);
    }
}

function MakeBoxesSameSize(firstBox,secondBox)
{
    if($(firstBox).length > 0 && $(secondBox).length > 0 && $(window).width() > 760)
    {
        $(firstBox).css("height","auto");
        $(secondBox).css("height","auto");
        var nearby_all = $(firstBox).outerHeight();
        var also_mention_box = $(secondBox).outerHeight();
        if(also_mention_box >= nearby_all)
        {
            $(firstBox).css("height",also_mention_box+"px");
            $(secondBox).css("height",also_mention_box+"px");
        }
        else if(nearby_all >= also_mention_box)
        {
            $(firstBox).css("height",nearby_all+"px");
            $(secondBox).css("height",nearby_all+"px");
        }
        else
        {
            $(firstBox).css("height","258px");
            $(secondBox).css("height","258px");
        }
    }
}

function getRecentWordList(lookup_url)
{
    $.get(lookup_url,"",function(data){
        $("#UserWordList_container").html(data);
        $("#UserWordList_container").show();
        if($.cookie("login_token") != null) {
            $.post("/getrecent/userlist/"+$.cookie("login_user_slug")+"/","",function(data){
                $("#myWordListData").html(data)
            });
        }
    });
}
function onSignIn(googleUser) {
    var profile = googleUser.getBasicProfile();
    var email;
    var id;
    var fname;
    var lname;
    var token;
    token = profile.getId().substring(0, 100);
    $('#gsi_access_token').val(token);
    id = profile.getId();
    fname = profile.getGivenName();
    lname = profile.getFamilyName();
    email = profile.getEmail()
    $.post("/save/user/", "fname=" + fname + "&lname=" + lname + "&id=" + id + "&email=" + email,function(data){
        if(data["success"] == "created") {
            afterLoginProcess(data);
        }
    });    
    $('#loginModal').foundation('reveal', 'close'); 
}
                      
function BrowseBoxCounter()
{
    $(".bx-default-pager").show();
    var totalBoxes= $(".bx-pager-item").length;
    var boxesToFit = Math.round($(".bx-controls").width()/$(".bx-pager-item").width());
    var lastItem=0;
    if(totalBoxes > boxesToFit)
    {
        boxesToFit=(boxesToFit-2)
        var Seprator= Math.round(totalBoxes/boxesToFit);
        Seprator = (Seprator == 1) ? 2 : Seprator;
        var bx_counter=0;
        $(".bx-pager-item").hide();
        $(".bx-pager-item").each(function(){
           if((bx_counter%Seprator) == 0 || (bx_counter == ($(".bx-pager-item").length-1)))
           {
               if(bx_counter == ($(".bx-pager-item").length-1))
                {
                    $(this).show();
                    if($(".bx-pager-item:visible").length > boxesToFit)
                    {
                        lastItem.hide();
                    }

                }
                else
                {
                    $(this).show();
                    lastItem=$(this);
                }
           }
           bx_counter++;
        });
    }
    
    $('.bx-default-pager').css('margin-left','-22px');
    $('.bx-default-pager').css('width',$('.bx-wrapper').width()+40+'px');
    if($(".bx-pager-item").length <= 1)
    {
        $(".bx-pager-item").hide();
        $(".bx-wrapper").css("margin-bottom","0");
    }
}

function ControlBoxes()
{
    if($('.bxslider').length > 0)
    {
        var singleItemWidth = 100;
        var partialAdjust = 80;
        
        var ShowTotal = Math.round((($(".definitions_slider").width())-($(".bx-prev").width()*2))/singleItemWidth);
        ShowTotal = (ShowTotal == 1) ? 1 : (ShowTotal-1);
        slider = $('.bxslider').bxSlider({
            infiniteLoop: false,
            responsive: true,
            maxSlides: ShowTotal,
            slideWidth: singleItemWidth,
            hideControlOnEnd: true,
            moveSlides: ShowTotal,
            onSliderLoad: function(currentIndex){
                $(".slider_item").css("visibility","visible");
                $(".bxSliderLoader").remove();
                if($(".slider_item").length <= ShowTotal)
                {
                    $(".bx-controls").hide();
                    $(".bx-wrapper").css("margin-bottom","0");
                }
                
                var totalDot = $(".bx-pager-item").length;
                var removeIndex = 0;
                var lastFilled=2;
                var breakLoop=false;
                for(var i=1; i <= totalDot; i++)
                {
                    lastFilled=(lastFilled-1);
                    for(var j=1; j <= ShowTotal; j++)
                    {
                        if(lastFilled == $(".slider_item").length)
                        {
                            breakLoop=true;
                        }
                        
                        if(breakLoop)
                        {
                            break;
                        }
                        
                        lastFilled++;
                    }
                    
                    if(breakLoop)
                    {
                        removeIndex=(i+1);
                        break;
                    }
                    
                }
    
                if(removeIndex > 1)
                {
                    $(".bx-pager-item:nth-child("+removeIndex+")").remove();
                }
            },
            onSlideBefore: function($slideElement, oldIndex, newIndex){
                    $(".slider_item").css("visibility","visible");
                    $(".slider_item").removeClass('hidden');
                    $(".slider_item").removeClass('visible');
                    if ( !$('.bx-clone').is(":visible") ) {
                        $('.bx-clone').show();
                    }
            },
            onSlideAfter: function($slideElement, oldIndex, newIndex){
                var mainOffsetLeft = $(".bx-viewport").offset().left;
                var mainOffsetRight = mainOffsetLeft+$(".bx-viewport").width();
                
                $(".slider_item").css("visibility","visible");
                $(".slider_item").each(function(){
                    var currItemOffsetLeft = $(this).offset().left;
                    var currItemOffsetRight = currItemOffsetLeft+partialAdjust;
                    if(((currItemOffsetLeft) < mainOffsetLeft) || (currItemOffsetRight > mainOffsetRight))
                    {
                        $(this).addClass('hidden');
                        $(this).css("visibility","hidden");
                    }
                    else
                    {
                        $(this).addClass('visible');
                    }
                });
                
                var lastItem = $('.slider_item.visible:first').offset().left;
                var nextItem = $(".bx-viewport").offset().left;
                var setTransform= ((lastItem-mainOffsetLeft));
                
                // Replace with transform, if supported
                if('WebkitTransform' in document.body.style) 
                {
                    var CurrentTransformValue = eval($('.bxslider').css('transform'));
                    var transformVal= "translate3d(" + (CurrentTransformValue-setTransform) + "px, 0, 0)";
                    $('.bxslider').css('-webkit-transform',transformVal);
                }
                else if('transform' in document.body.style) 
                {
                    var CurrentTransformValue = eval($('.bxslider').css('transform'));
                    var transformVal= "translate3d(" + (CurrentTransformValue-setTransform) + "px, 0, 0)";
                    $('.bxslider').css('transform',transformVal);
                    $('.bxslider').css('-ms-transform',transformVal);
                    $('.bxslider').css('-moz-transform',transformVal);
                }
                else
                {
                    var CurrentTransformValue = $('.bxslider').css('left').replace("px","");
                    if($('.slider_item.visible:first').offset().left != undefined)
                    {
                        $('.bxslider').css('left',(CurrentTransformValue)+"px");
                    }
                }
            }
        });
    }
    BrowseBoxCounter();
}

  

function detectBrowser()
{
    var N= navigator.appName;
    var UA= navigator.userAgent;
    var temp;
    var browserVersion= UA.match(/(opera|chrome|safari|firefox|msie|Trident)\/?\s*(\.?\d+(\.\d+)*)/i);
    if(browserVersion && (temp= UA.match(/version\/([\.\d]+)/i))!= null)
    browserVersion[2]= temp[1];
    browserVersion= browserVersion? [browserVersion[1]]: "";
    return browserVersion.toString();
};

function floatHeader(myWidth) 
{
   if(myWidth >= 750) 
   {
      if($(window).scrollTop() > ($(".floating-nav").height()+$("#ad-super-www").height()+10))
      {
        $(".floating-header").css({"position": "fixed", "top": "0px"});
      }
      else 
      {
        $(".floating-header").css({"position": "static", "top": "auto"});
      }
   } 
}

function GoogleCustomSearch()
{
   if($('.gsc-search-box').length > 0)
        {
           $('.prefix').clone().appendTo('.gsc-search-button');
           $('.gsc-search-button .prefix').css({'padding':'auto','height':'30px','width':'45px'});
           $('.gsc-search-button .prefix .search_icon_symbol img').css({'margin-top':'4px','width':'20px'});
           $('.gsc-search-button .prefix').attr('onClick','');
           $('.gsc-search-button .prefix').click(function(){
               $('.gsc-search-button .gsc-search-button').trigger('click');
           });
           $('.gsc-clear-button .gsc-clear-button').clone().appendTo('.gsc-input');
           $('.gsc-input .gsc-clear-button').css({'float':'right','margin-top':'-34px','cursor':'pointer','position':'relative'});
           $('.gsc-input .gsc-clear-button').click(function(){
              $('.gsc-clear-button .gsc-clear-button').trigger('click');
           });
        }
}

function offsetAnchor() 
{
    if(location.hash.length !== 0) {
        window.scrollTo(window.scrollX, window.scrollY - 100);
    }
}

function RenderAutoComplete(field, parent_form)
{
     $("#"+field+"").autocomplete({
        source: function(request,response){
            var searchedItem = $("#"+field+"").val();
            if(searchedItem.length > 2)
            {
                if(field == "yd_search_bar" || field == "yd_search_bar2")
                {
                    $(".search-clear-icon").show();
                }
                $.getJSON("/keywordhelp/" + searchedItem + "/", function(data) {
                var suggestions = [];
                response( $.map( data, function( item ) {
                        return {
                            label: item,
                            value: item
                        }
                    }));
                });
            }
        },
        minLength: 3,
        delay: 100,
        select: function(e,ui) {
            $("#"+field).val(ui.item.value);
            $('#'+parent_form).submit();
        }
    });
}
