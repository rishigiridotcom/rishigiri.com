var listLoaded = false;
var searchPerformed = false;
function AddToWordList(headword, slug, dictionary_slug, gsi_access_token, word_list_id)
{
    
}

$(document).on("click",'#floater-images',function(){
	$(".floaterButtons").removeClass("active");
	$("#GoogleImagesSearch").trigger("click");
	$(this).find("button").addClass("active");
});

$(document).on("click",'#floater-biography',function(){
	$(".floaterButtons").removeClass("active");
	$("#definitions_panel p.title").trigger("click")
	$(this).find("button").addClass("active");
});

$(document).on("click",'.top_rated_wordlists_h3',function(){
	if(document.location.href.indexOf('publiclists') > -1)
	{
		$(".sortable_headers").last().trigger("click");
	}
});

$(document).on("click",'.shareSocial',function(){
	var shareTitle = $(this).attr("title");
	var shareUrl = $(this).attr("data-href");
	window.open(encodeURI(shareUrl), 
	shareTitle, "height=300,width=550,resizable=1" );
});

$(document).on("click",".wordlist-user-name",function(){
		var LocationUrl = $(this).attr('href');
		if($.cookie("login_token") != null)
		{
			var loginUserSlug=$.cookie("login_user_slug");
			if(LocationUrl.indexOf(loginUserSlug) > -1)
			{
				LocationUrl=LocationUrl+"mywordlist/"
			}
		}
		window.location.href=LocationUrl;
		return false;
});
$(document).on("click",".wordlist-name-tag",function(){
		var WLocationUrl = $(this).attr('href');
		var WLSlug = $(this).attr('slug');
		if($.cookie("login_token") != null)
		{
			var WloginUserSlug=$.cookie("login_user_slug");
			if((WLocationUrl.indexOf(WloginUserSlug) > -1) && (WLocationUrl.indexOf(WLSlug) > -1))
			{
				WLocationUrl="/"+WloginUserSlug+"/mywordlist/"+WLSlug+"/"
			}
		}
		window.location.href=WLocationUrl;
		return false;
});	
$(document).on("click",".TwitterSocialButton",function(e) {
	var tweetContent=$(this).parents('.QuotesContent').find('p.quoteContent').text();
	tweetContent=tweetContent.replace(/(\r\n|\n|\r)/gm,"");
	if(tweetContent.length > 110)
	{
		tweetContent = jQuery.trim(tweetContent).substring(0, 113).trim(this)+ "...";
	}
	var tweetUrl=$("#shareUrl").val()+"#overlay="+$(this).parents('.QuotesContent').attr('id');
	if(tweetContent != '')
	{
		e.preventDefault();
		window.open( "http://twitter.com/share?url=" + 
		encodeURIComponent(tweetUrl) + "&text=" + 
		encodeURIComponent(tweetContent.trim()+"\n") + "&count=none/", 
		"tweet", "height=300,width=550,resizable=1" ) 
		
	}
});

$(document).on("click",".QuotefacebookIcon",function(e) {
	var pTag = $(this).parents(".quote_pic").find('p.quoteContent');
	var picTureSrc = $(this).parents(".quote_pic").find('.quotepicturesrc').attr('src');
	if(picTureSrc == undefined)
	{
		picTureSrc="http://www.yourdictionary.com/images/yd-share.jpg";
	}
	var fbContent=pTag.text();
	fbContent=fbContent.replace(/(\r\n|\n|\r)/gm,"");
	var fbUrl=$("#shareUrl").val()+"#overlay="+$(this).parents('.item').attr('id')
	var QuoteTitle = document.title;
	
	if(fbContent == '')
	{
		fbContent=QuoteTitle;
	}
	
	if(fbContent != '')
	{
		e.preventDefault();
		FB.ui({
				method: 'feed',
				name: QuoteTitle,
				description: (fbContent),
				link: fbUrl,
				picture: picTureSrc
			},
			function(response) {
				if (response && response.post_id) {
					var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false )
				}
			}
		);
	}
});

$(document).on("click",".QuotePicturePinterestIcon",function(e) {
	var pinContent= $(this).attr("href");
    if(pinContent != '')
    {
		e.preventDefault();
        window.open( pinContent,"pin it", "height=300,width=550,resizable=1") 
        
    }
});

$(document).on("click",".QuotePictureTwitterIcon",function(e) {
	var tweetContent="YourDictionary Picture Quotes";
	var tweetUrl=$("#shareUrl").val()+"#overlay="+$(this).parents('.item').attr('id');
	if(tweetContent != '')
	{
		e.preventDefault();
		window.open( "http://twitter.com/share?url=" + 
		encodeURIComponent(tweetUrl) + "&text=" + 
		encodeURIComponent(tweetContent.trim()+"\n") + "&count=none/", 
		"tweet", "height=300,width=550,resizable=1" )		
	}
});

function LoadWordList()
{
    var output = "";
    var regularURL = "";
                                                 
    if(words == null) return;

    var hostString = location.hostname;

    var hostParts = hostString.split(".");
    if (hostParts.length == 4)
    {
        regularURL = "www." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        investURL = "invest." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        scienceURL = "science." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        cultureURL = "culture." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        biographyURL = "biography." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        medicalURL = "medical." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        businessURL = "business." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        abbreviationsURL = "abbreviations." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        lawURL = "law." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        computerURL = "computer." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        thesaurusURL = "thesaurus." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        quotesURL = "quotes." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        examplesURL = "sentence." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        idiomsURL = "idioms." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
        imagesURL = "images." + hostParts[1] + "." + hostParts[2] + "." + hostParts[3];
    }
    else
    {
        regularURL = "www." + hostParts[1] + "." + hostParts[2];
        investURL = "invest." + hostParts[1] + "." + hostParts[2];
        scienceURL = "science." + hostParts[1] + "." + hostParts[2];
        cultureURL = "culture." + hostParts[1] + "." + hostParts[2];
        biographyURL = "biography." + hostParts[1] + "." + hostParts[2];
        medicalURL = "medical." + hostParts[1] + "." + hostParts[2];
        businessURL = "business." + hostParts[1] + "." + hostParts[2];
        abbreviationsURL = "abbreviations." + hostParts[1] + "." + hostParts[2];
        lawURL = "law." + hostParts[1] + "." + hostParts[2];
        computerURL = "computer." + hostParts[1] + "." + hostParts[2];
        thesaurusURL = "thesaurus." + hostParts[1] + "." + hostParts[2];
        quotesURL = "quotes." + hostParts[1] + "." + hostParts[2];
        examplesURL = "sentence." + hostParts[1] + "." + hostParts[2];        
        idiomsURL = "idioms." + hostParts[1] + "." + hostParts[2];
        imagesURL = "images." + hostParts[1] + "." + hostParts[2];
    }

    var wordList = words.split("||");
    for(var i = 0; i < wordList.length; i++)
    {
        var word = wordList[i];
        var wordParts = word.split("|");
        if (wordParts.length == 2 || wordParts[2] == "college" || wordParts[2] == "undefined")
        {
              output += '<li><a href="http://' + regularURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
        else if (wordParts[2] == "invest")
        {
           output += '<li><a href="http://' + investURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
        else if (wordParts[2] == "science")
        {
           output += '<li><a href="http://' + scienceURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
        else if (wordParts[2] == "culture")
        {
           output += '<li><a href="http://' + cultureURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
        else if (wordParts[2] == "biography")
        {
           output += '<li><a href="http://' + biographyURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
        else if (wordParts[2] == "medical")
        {
           output += '<li><a href="http://' + medicalURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }        
        else if (wordParts[2] == "abbreviations")
        {
           output += '<li><a href="http://' + abbreviationsURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }        
        else if (wordParts[2] == "law")
        {
           output += '<li><a href="http://' + abbreviationsURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }        
        else if (wordParts[2] == "computer")
        {
           output += '<li><a href="http://' + computerURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }  
        else if (wordParts[2] == "thesaurus")
        {
           output += '<li><a href="http://' + thesaurusURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }        
        else if (wordParts[2] == "quotes")
        {
           output += '<li><a href="http://' + quotesURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }        
        else if (wordParts[2] == "sentence")
        {
           output += '<li><a href="http://' + examplesURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        } 
        else if (wordParts[2] == "examples")
        {
           output += '<li><a href="http://' + examplesURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        } 
        else if (wordParts[2] == "idioms")
        {
           output += '<li><a href="http://' + idiomsURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        } 
        else if (wordParts[2] == "images")
        {
           output += '<li><a href="http://' + imagesURL + "/" + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
        else
        {
           output += '<li><a href="http://' + regularURL + "/" + wordParts[2] + '/' + wordParts[0] + '">' + wordParts[1] + '</a></li>';
        }
    }

    if(output != null && output != "")
    {
        $('#recent-words-slot').replaceWith('<ol class="words">' + output + '</ol>');
    }
}

function GenerateWordlistThumbsNoFlag()
{
    var idsString = '';
    $('.wordlist_voting_content').each(function(){
        idsString += $(this).attr('id').replace("wordlist-","")+",";
    });

    if(idsString != '')
    {
        $.post("/vote/counts/wordlist/" + encodeURI(idsString.replace(/,(\s+)?$/, '')) +"/",'', function(data){
            $.each(data, function(key, val){
                var item = $('#wordlist-' + key);
                var count_up = '<span class="count-up">' + val.up + '</span>';
                var pipe = '<span class="pipe"></span>';
                var count_down = '<span class="count-down">' + val.down + '</span>';
                var button_up = '<button title="Vote Up" class="vote_up_img reset_button_style" onClick="ga(\'send\', \'event\', {eventCategory: \'Wordlist: Vote Up\', eventAction: \'Click\'});">&nbsp;</button>';
                var button_down = '<button title="Vote Down" class="vote_down_img reset_button_style" onClick="ga(\'send\', \'event\', {eventCategory: \'Wordlist: Vote Down\', eventAction: \'Click\'});">&nbsp;</button>';
                var appendString = '<div class="voting_content voting_right voting_quote"><div class="voting-up">' + count_up + button_up + '</div>'+pipe+'<div class="voting-down">' + count_down + button_down + '</div></div>';
                item.html(appendString);
            });
        });
    }
}
function GenerateWordlistThumbs()
{
    var idsString = '';
    $('.wordlist_voting_content').each(function(){
        idsString += $(this).attr('id').replace("wordlist-","")+",";
    });

    if(idsString != '')
    {
        $.post("/vote/counts/wordlist/" + encodeURI(idsString.replace(/,(\s+)?$/, '')) +"/",'', function(data){
            $.each(data, function(key, val){
                var item = $('#wordlist-' + key);
                var count_up = '<span class="count-up">' + val.up + '</span>';
                var pipe = '<span class="pipe"></span>';
                var count_down = '<span class="count-down">' + val.down + '</span>';
                var button_up = '<button title="Vote Up" class="vote_up_img reset_button_style" onClick="ga(\'send\', \'event\', {eventCategory: \'Wordlist: Vote Up\', eventAction: \'Click\'});">&nbsp;</button>';
                var button_down = '<button title="Vote Down" class="vote_down_img reset_button_style" onClick="ga(\'send\', \'event\', {eventCategory: \'Wordlist: Vote Down\', eventAction: \'Click\'});">&nbsp;</button>';
                var button_flag = '<button title="Suggest delete" class="flag_button reset_button_style" onClick="ga(\'send\', \'event\', {eventCategory: \'Wordlist: Flag\', eventAction: \'Click\'});">&nbsp;</button>';
                var appendString = '<div class="voting_content voting_right voting_quote"><div class="voting-up">' + count_up + button_up + '</div>'+pipe+'<div class="voting-down">' + count_down + button_down + '</div><div class="voting-flag">' + button_flag + '</div></div>';
                item.html(appendString);
            });
        });
    }
}
function ExecuteVotingOnQuotes()
{
	$(document).on("click",".count-up,.vote_up_img,.count-down,.vote_down_img,.flag_button",function(){
		
			var key = $(this).parents(".quote_voting_content").attr("id").replace("quo-","");
			var eventClass=$(this).attr('class');
			var textObj="";
			var buttonObj="";
			var postURL="";
			var addFlagClass=false;
			if(eventClass.indexOf("count-up") > -1 || eventClass.indexOf("vote_up_img") > -1)
			{
				var textObj = $(this).parents(".quote_voting_content").find(".count-up");
				var buttonObj = $(this).parents(".quote_voting_content").find(".vote_up_img");
				var postURL="/vote/up/quote/" + key + "/";
			}
			else if(eventClass.indexOf("count-down") > -1 || eventClass.indexOf("vote_down_img") > -1)
			{
				var textObj = $(this).parents(".quote_voting_content").find(".count-down");;
				var buttonObj = $(this).parents(".quote_voting_content").find(".vote_down_img");
				var postURL="/vote/down/quote/" + key + "/";
			}
			else if(eventClass.indexOf("flag_button") > -1)
			{
				var buttonObj = $(this).parents(".quote_voting_content").find(".flag_button");
				var postURL="/flag/quote/" + key + "/";
				addFlagClass=true;
			}

			if(postURL != "")
			{
				buttonObj.html($(".loader").html());
				$.post(postURL,"", function(data){
					if(textObj != "")
					{
						textObj.text(data);
						textObj.css("pointer-events","none");
					}
					if(buttonObj != "")
					{
						buttonObj.html("&nbsp;");
						buttonObj.attr("disabled", "disabled");
						if(addFlagClass)
						{
							buttonObj.addClass("flagged");
						}
					}
				});
			}
	});
}
function ExecuteVotingOnWordlists()
{
    $(document).on("click",".count-up,.vote_up_img,.count-down,.vote_down_img,.flag_button",function(){
        
            var key = $(this).parents(".wordlist_voting_content").attr("id").replace("wordlist-","");
            var eventClass = $(this).attr('class');
            var textObj = "";
            var buttonObj = "";
            var postURL = "";
            var addFlagClass = false;
            if(eventClass.indexOf("count-up") > -1 || eventClass.indexOf("vote_up_img") > -1)
            {
                var textObj = $(this).parents(".wordlist_voting_content").find(".count-up");
                var buttonObj = $(this).parents(".wordlist_voting_content").find(".vote_up_img");
                var postURL = "/vote/up/wordlist/" + key + "/";
            }
            else if(eventClass.indexOf("count-down") > -1 || eventClass.indexOf("vote_down_img") > -1)
            {
                var textObj = $(this).parents(".wordlist_voting_content").find(".count-down");;
                var buttonObj = $(this).parents(".wordlist_voting_content").find(".vote_down_img");
                var postURL = "/vote/down/wordlist/" + key + "/";
            }
            else if(eventClass.indexOf("flag_button") > -1)
            {
                var buttonObj = $(this).parents(".wordlist_voting_content").find(".flag_button");
                var postURL = "/flag/wordlist/" + key + "/";
                addFlagClass = true;
            }

            if(postURL != "")
            {
                buttonObj.html($(".loader").html());
                $.post(postURL,"", function(data){
                    if(textObj != "")
                    {
                        textObj.text(data);
                        textObj.css("pointer-events","none");
                    }
                    if(buttonObj != "")
                    {
                        buttonObj.html("&nbsp;");
                        buttonObj.attr("disabled", "disabled");
                        if(addFlagClass)
                        {
                            buttonObj.addClass("flagged");
                        }
                    }
                });
            }
    });
}
$(document).on("click","#create_wordlist_button,#add_wordlist_button,#follow_word_list,#follow_user",function(e){
	$("#addword_list_form").trigger('reset');
	$("#continue_and_submit").hide();
	$("#cancel_and_close").hide();
	if($(".addWordsListButtons").length > 0)
	{
		$(".addWordsListButtons").first().show();
	}
	else if($(".addWordsListButtons").length > 0)
	{
		$(".addWordsButtons").first().show();
	}
	
	if($.cookie("login_token")) {
		if($("#word_list_from_section").css("display") == "block" || $("#response_div").css("display") == "block") {
			return false;
		}
		
		if($(this).attr("id") == "add_wordlist_button") {
			
			if(!listLoaded) {
				$("#render_word_lists").width(245);
				$("#add_to_list_loader").show();
				$.post("/word_list/get_all/","",function(data,status,xhr){
					listLoaded = true;
					var ct = xhr.getResponseHeader("content-type") || "";
					if (ct.indexOf('html') > -1) {
					  $("#render_word_lists").html(data);
					  $("#add_to_list_loader").hide();
					} else {
					    $("#render_word_lists div:first").show();
						$("#add_to_list_loader").hide();
						var className = "";
						$.each(data,function(index,wordlist){
							if(index > 4) {
								className = "hide";
							}
							$("#word-lists-all").append("<div class='"+className+"' ><a class='add_item_to_wordlist' href='javascript:void(0);' data-id='"+wordlist.id+"'>"+wordlist.title+"</a></div>");
						});
						if(data.length < 5) {
							$("#load-more-lists").remove();
						}
					}
					
				});
			}
			$("#render_word_lists").slideToggle();
			if($("#render_word_lists").attr("device")=="desktop")
			{	
				$("#render_word_lists").css("max-height",parseInt($(window).height() - $(".add-to-wordlist").offset().top - 50 + $(window).scrollTop()) + "px");
			}
			else
			{
				$("#render_word_lists").css("max-height","")
				
			}
		} else {
			$("#word_list_from_section").slideToggle();
		}
		$("#word_error_div").hide();
	} else {
		$.cookie("after_login_javascript", $(this).attr("id"));
		triggerLoginPopup();
		return false;
	}
});

$(document).on("click", "#follow_word_list", function() {
	if($.cookie("login_token")) {
		$("#wait_for_follow_unfollow").show();
		$.post($(this).attr('action_url'),"",function(data){
			$("#follow_unfollow_span").html(data);
			$("#wait_for_follow_unfollow").hide();
		});
	}
});
$(document).on("click", "#unfollow_word_list", function() {
	if($.cookie("login_token")) {
		$("#wait_for_follow_unfollow").show();
		$.post($(this).attr('action_url'),"",function(data){
			$("#follow_unfollow_span").html(data);
			$("#wait_for_follow_unfollow").hide();
		});
	}
});

$(document).on("click", "#follow_user", function() {
	if($.cookie("login_token")) {
		$("#wait_for_follow_unfollow").show();
		$.post($(this).attr('action_url'),"",function(data){
			$("#follow_unfollow_span").html(data);
			$("#wait_for_follow_unfollow").hide();
		});
	}
});
$(document).on("click", "#unfollow_user", function() {
	if($.cookie("login_token")) {
		$("#wait_for_follow_unfollow").show();
		$.post($(this).attr('action_url'),"",function(data){
			$("#follow_unfollow_span").html(data);
			$("#wait_for_follow_unfollow").hide();
		});
	}
});

$(document).on("click", "#load-more-lists", function() {
	$("#render_word_lists").width(($(".contain-to-grid").width() - $("#add-to-wordlist-data").offset().left) - 70);
	if($("#render_word_lists").attr("device")=="desktop")
	{	
		$("#render_word_lists").css("max-height",parseInt($(window).height() - $("#add-to-wordlist-data").offset().top - 50 + $(window).scrollTop()) + "px");
	}
	else
	{
		
		$("#render_word_lists").css("max-height","")
		
	}
	
	$("#word-lists-all div").show();
	$("#load-more-lists").remove();
	return false;
});
$(document).on("click","#cancel_and_close",function() {
	
	if($(".close-reveal-modal").length > 0)
	{
		$(".close-reveal-modal").trigger("click");
	}
	else if($("#close_word_add_form").length > 0)
	{
		$("#close_word_add_form").trigger("click");
	}
	else
	{
		if($("#go-back-to-word-list").length > 0)
		{
			window.location.href=$("#go-back-to-word-list").val();
		}
	}
	
});
$(document).on("click","#close_word_add_form",function() {
	$("#word_list_from_section").hide();
	$("#wltitle").val("");
	$("#wldescription").val("");
	$("#word_error_div").hide();
});
$(document).on("click","#creat_word_list_button",function(){
	$("#word_list_from_section").show();
	$("#word_list_from_section").css("left",($("#add_word_list_section").css("left")));
	$("#render_word_lists").hide();
	$("#word_error_div").hide();
});
$(document).on("click","#close_response_div",function(){
	$("#response_div").hide();
});
$(document).on("click",".addWordsListButtons",function(){
	
	var CurrentClicked=$(this).attr("id");
	var validateWord="yes";
	if(CurrentClicked == "continue_and_submit")
	{
		validateWord="no";
	}
	var obj = $(this);
	var CaseFor=$(this).attr("for");
	var hostNameArray = location.hostname.split(".");
	var regularURL = "wordlist." + hostNameArray[1] + "." + hostNameArray[2];
	if (hostNameArray.length == 4)
    {
        regularURL = "wordlist." + hostNameArray[1] + "." + hostNameArray[2] + "." + hostNameArray[3];
	}
	
	if(CaseFor == "wordlisthome" || CaseFor == "userwordlist") {
		var wordsEntered = $("#wlwords").val().replace(/\n/g, ",").trim(",");
		if(wordsEntered.indexOf(".") > -1) {
			$("#word_error_div").html("Please enter words separated by comma instead of period.");
			$("#word_error_div").show();
			return false;
		} else if(wordsEntered.trim(",") == "") {
			$("#word_error_div").html("Please enter words.");
			$("#word_error_div").show();
			return false;
		}
		$("#wlwords").val(wordsEntered);
	}
	
	if(validateWordListForm())
	{
		$("#word_error_div").hide();
		$("#save_to_list_loader").show();
		$.post("/wordlistaction/AddList/",$("#addword_list_form").serialize()+"&validateWord="+validateWord,function(data){
			var ResponseData=data;
			if(ResponseData["success"] == "true")
			{
				$("#word_list_from_section").hide();
				if(CaseFor == "wordlisthome") {
					$("#response_data_container").html("Created <a href='http://"+regularURL+"/"+(ResponseData["wl_author"])+"/mywordlist/"+ResponseData["wl_slug"]+"/'><b>"+$("#wltitle").val()+"</b></a>  list.");
					var currUsrURL=$("#current_user_list_url").val();
				}
				else if(CaseFor == "userwordlist")
				{
					$("#response_div").css("left",($("#add_word_list_section").css("left")));
					$("#response_data_container").html("Created <a href='http://"+regularURL+"/"+(ResponseData["wl_author"])+"/mywordlist/"+ResponseData["wl_slug"]+"/'><b>"+$("#wltitle").val()+"</b></a>  list.");
				}
				else {
					$("#response_div").css("left",($("#add_word_list_section").css("left")));
					$("#response_data_container").html("Added <b>"+ResponseData["wl_word"]+"</b> to list<br><a href='http://"+regularURL+"/"+(ResponseData["wl_author"])+"/mywordlist/"+ResponseData["wl_slug"]+"/'>"+$("#wltitle").val()+"</a>");
					$("#word-lists-all").prepend("<div><a class='add_item_to_wordlist' href='javascript:void(0);' data-id='"+ResponseData["wl_id"]+"'>"+$("#wltitle").val()+"</a></div>");
					$("#word-lists-all div:eq(5)").hide()
				}
				$("#wltitle").val("");
				$("#wldescription").val("");
				$("#response_div").show();
				$("#save_to_list_loader").hide();
			} else {
				$("#word_error_div").html(ResponseData["error"]);
				$("#word_error_div").show();
				if(ResponseData["error"].indexOf("are not available in YourDictionary") > -1)
				{
					$("#continue_and_submit").show();
					$("#cancel_and_close").show();
					$(".addWordsListButtons").first().hide();
				}
				else
				{
					$("#continue_and_submit").hide();
					$("#cancel_and_close").hide();
					$(".addWordsListButtons").first().show();
				}
				$("#save_to_list_loader").hide();
			}
		});
	}
});

function validateWordListForm() {
	var bReturn = false;
	if($("#wltitle").val().trim() == "")
	{
		$("#word_error_div").html("Please enter Title for word list.");
		$("#word_error_div").show();
	}else if( $("#wltitle").val().trim().length > 49 || $("#wltitle").val().trim().length < 3) {
		$("#word_error_div").html("Title must be between 3 and 50 charcters.");
		$("#word_error_div").show();
	}else {
		bReturn = true;
	}
	
	return bReturn;
}

$(document).on("click",".create_new_wordlist", function() {
	 var user_id = $.cookie("login_token");
	 if(user_id != null)
	 {
		 $.post("/createnewwordlist/"+user_id+"/","",function(data){
			 $title = 'My Word List';
			 data = parseInt(data);
			 if(data > 0){
				data = data+1;
				$('#wltitle').val($title+" "+data);
			 } else {
				$('#wltitle').val($title);
			 }
		 });
	 }
});

if($('#ydWordListQ').length > 0)
{
	$('#ydWordListQ').autocomplete({
		source: function(request,response){
		   
		var searchedItem = $('#ydWordListQ').val().trim().replace(/[^\w\s]/gi,'');
		if(searchedItem.length > 2)
		{
			$.getJSON("/wordlist/keywords/"+searchedItem+"/", "", function(data) {
				var suggestions = [];
				response( $.map( data, function( item ) {
					return {
						label: item.word,
						value: item.word
					}
				}));
			});
		 }
	   },
	   open: function (event, ui){
		   var AuthorAnchorText=$( "a:contains('Authors Matching')" ).text();
           $( "a:contains('Authors Matching')" ).parent("li").replaceWith('<span class="author_li">'+AuthorAnchorText+'</span>');
		   
		   var WordListAnchorText=$( "a:contains('Lists Matching')" ).text();
           $( "a:contains('Lists Matching')" ).parent("li").replaceWith('<span class="author_li">'+WordListAnchorText+'</span>');
       }
	});
}

$(function(){
	$(document).on("click","#AddWords", function(){
		$("#AddWordsModal").foundation('reveal', 'open');
		$("#wlwords").val("");
		$("#continue_and_submit").hide();
		$("#cancel_and_close").hide();
		$("#add_words_error_div").html("");
		if($(".addWordsButtons").length > 0)
		{
			$(".addWordsButtons").first().show();
		}
	});
	
});

$(window).load(function(){
	setTimeout(function() {
		if(($.cookie("after_login_javascript") != '') && $.cookie("login_token")) {
			$("#"+$.cookie("after_login_javascript")).trigger('click');
			$.cookie("after_login_javascript","");
		}
	}, 1000);
})
